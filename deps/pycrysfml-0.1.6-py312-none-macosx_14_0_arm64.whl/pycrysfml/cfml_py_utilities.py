from . import crysfml08lib
import numpy as np

def cw_powder_pattern_from_dict(json : dict):
    """
    Computes a powder pattern from information provided by a
    dictionary. This subroutine was introduced mainly for
    Python applications. Python can easily transform a json file
    into a dictionary.

    Parameters
    ----------
    json
        Python type    : dict
        Fortran type   : dict
        Fortran intent : inout
        Description    : json file content

    Returns
    -------
    xc
        Python type    : np.ndarray
        Fortran type   : real
        Fortran intent : out
        Description    : two theta angle
    yc
        Python type    : np.ndarray
        Fortran type   : real
        Fortran intent : out
        Description    : calculated intensity
    """

    xc,yc = crysfml08lib.f_cw_powder_pattern_from_dict(json)
    return xc,yc

def tof_powder_pattern_from_dict(json : dict):
    """
    Computes a powder pattern from information provided by a
    dictionary. This subroutine was introduced mainly for
    Python applications. Python can easily transform a json file
    into a dictionary.

    Parameters
    ----------
    json
        Python type    : dict
        Fortran type   : dict
        Fortran intent : inout
        Description    : json file content

    Returns
    -------
    xc
        Python type    : np.ndarray
        Fortran type   : real
        Fortran intent : out
        Description    : two theta angle
    yc
        Python type    : np.ndarray
        Fortran type   : real
        Fortran intent : out
        Description    : calculated intensity
    """

    xc,yc = crysfml08lib.f_tof_powder_pattern_from_dict(json)
    return xc,yc
# easydiffraction/utils/__init__.py

from .utils import download_from_repository, is_notebook

__all__ = [
    "download_from_repository",
    "is_notebook"
]